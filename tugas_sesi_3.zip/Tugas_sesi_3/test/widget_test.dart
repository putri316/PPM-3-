import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

import 'package:tugas_sesi_3/main.dart';
import 'package:tugas_sesi_3/providers/cart_provider.dart';
import 'package:tugas_sesi_3/providers/theme_provider.dart';

void main() {
  Widget createTestApp() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => CartProvider()),
        ChangeNotifierProvider(create: (_) => ThemeProvider()),
      ],
      child: const NusaBookstoreApp(),
    );
  }

  testWidgets('NusaBookstore menampilkan katalog buku', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(createTestApp());

    expect(find.text('NusaBookstore'), findsOneWidget);
    expect(find.text('Pemrograman Flutter'), findsOneWidget);
    expect(find.text('Dasar-Dasar Python'), findsOneWidget);
    expect(find.text('Belajar Database'), findsOneWidget);

    await tester.scrollUntilVisible(find.text('Artificial Intelligence'), 300);

    expect(find.text('Artificial Intelligence'), findsOneWidget);
  });

  testWidgets('Menambahkan buku ke keranjang', (WidgetTester tester) async {
    await tester.pumpWidget(createTestApp());

    await tester.tap(find.text('Tambah ke Keranjang').first);

    await tester.pump();

    expect(find.text('1'), findsOneWidget);
  });

  testWidgets('Mengubah tema aplikasi', (WidgetTester tester) async {
    await tester.pumpWidget(createTestApp());

    final lightTheme = Theme.of(tester.element(find.text('NusaBookstore')))
        .brightness;

    await tester.tap(find.byTooltip('Ganti Tema'));

    await tester.pumpAndSettle();

    final darkTheme = Theme.of(tester.element(find.text('NusaBookstore')))
        .brightness;

    expect(lightTheme, Brightness.light);
    expect(darkTheme, Brightness.dark);
  });
}
